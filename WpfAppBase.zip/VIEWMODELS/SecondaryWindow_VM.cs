﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.ViewModels
{
	public partial class SecondaryWindow_VM : ObservableRecipient
	{
		[ObservableProperty]
		private string _message;
	}
}
