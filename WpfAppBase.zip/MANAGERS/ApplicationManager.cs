﻿using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Managers
{
	class ApplicationManager : ObservableRecipient
	{
		private static readonly Lazy<ApplicationManager> _lazyInstance =
			new(() => new());

		public static ApplicationManager Instance => _lazyInstance.Value;

		public IServiceProvider ServiceProvider { get; }
		public IExampleManager ExampleManager { get; }

		private ApplicationManager()
		{
			ServiceProvider = new ServiceCollection()
				.AddSingleton<IExampleManager, ExampleManager>()
				.BuildServiceProvider();

			ExampleManager = ServiceProvider.GetRequiredService<ExampleManager>();
		}
	}
}
