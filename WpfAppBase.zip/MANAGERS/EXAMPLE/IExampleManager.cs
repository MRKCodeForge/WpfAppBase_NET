﻿namespace $safeprojectname$.Managers
{
    interface IExampleManager
    {
    }
}
