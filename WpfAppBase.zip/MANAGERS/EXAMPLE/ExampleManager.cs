﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace $safeprojectname$.Managers
{
    public class ExampleManager : ObservableRecipient, IExampleManager
    {
    }
}
